<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrderTotal extends Model
{
    //
}
